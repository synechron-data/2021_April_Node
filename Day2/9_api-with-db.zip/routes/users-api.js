var express = require('express');
var cors = require('cors');

var router = express.Router();

const usersApiCtrl = require('../controllers/users-api-controller');

router.use(cors());

router.get('/', usersApiCtrl.getUsers);

router.get('/:userid', usersApiCtrl.getUser);

router.post('/', usersApiCtrl.createUser);

router.put('/:userid', usersApiCtrl.updateUser);

router.delete('/:userid', usersApiCtrl.deleteUser);

module.exports = router;
