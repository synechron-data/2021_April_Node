const http = require('http');
const fs = require('fs');
const express = require('express');
const logger = require('morgan');
const favicon = require('serve-favicon');

const app = express();

app.set('view engine', 'pug');

const employees = [{ id: 1, name: "Manish" },
{ id: 2, name: "Abhijeet" },
{ id: 3, name: "Ram" },
{ id: 4, name: "Abhishek" },
{ id: 5, name: "Ramakant" }];

app.use(logger('dev'));
app.use(express.static('public'));
app.use(favicon(__dirname + "/public/images/favicon.png"));

// app.use(function (req, res, next) {
//     console.log("Request - Middleware 1");
//     next();
//     console.log("Response - Middleware 1");
// });

// app.use(function (req, res, next) {
//     console.log("Request - Middleware 2");
//     next();
//     console.log("Response - Middleware 2");
// });

// app.use(function (req, res, next) {
//     var stTime = new Date().getTime();
//     next();
//     var enTime = new Date().getTime();
//     var tTime = enTime - stTime;
//     console.log(`${req.url} - Total Time ${tTime} ms`);
// });

app.get('/', (req, res) => {
    // console.log("Request Handler");
    res.render("index", { pageTitle: "Index View" });
});

app.get('/employees', (req, res) => {
    res.render("employees", { pageTitle: "Employees View" });
});

// -------------------------------------------------------- Hosting Code
const server = http.createServer(app);

server.listen(3000);

function onError(err) {
    console.log(err);
}

function onListening(err) {
    var address = server.address();
    console.log("Server started on port: ", address.port);
}

server.on('error', onError);
server.on('listening', onListening);