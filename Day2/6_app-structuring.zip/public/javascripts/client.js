$("#btnJS").click(function () {
    alert("Button Clicked...");
});