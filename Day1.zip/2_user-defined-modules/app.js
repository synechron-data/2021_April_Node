// require('./lib.js');

// const lib = require('./lib.js');
// // console.log(lib);

// console.log("Firstname: ", lib.firstname);
// console.log("Lastname: ", lib.lastname);
// console.log(lib.log("Hello"));

// let e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// Object Destructuring
const { Employee } = require('./lib.js');
let e1 = new Employee("Manish");
console.log(e1.getName());
e1.setName("Abhijeet");
console.log(e1.getName());