// console.log("lib.js file loaded");
// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

// var fname = "Manish";
// var lname = "Sharma";
// module.exports = { firstname: fname, lastname: lname };

// Named Exports
// var fname = "Manish";
// var lname = "Sharma";

// module.exports.firstname = fname;
// module.exports.lastname = lname;

// module.exports.log = function (message) {
//     return `From Lib - ${message}`;
// }

// Named Exports Shortcut
var fname = "Manish";
var lname = "Sharma";

exports.firstname = fname;
exports.lastname = lname;

exports.log = function (message) {
    return `From Lib - ${message}`;
}

// class Employee {
//     constructor(name) {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     setName(value) {
//         this._name = value;
//     }
// }

// exports.Employee = Employee;

// exports.Employee = class Employee {
//     constructor(name) {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     setName(value) {
//         this._name = value;
//     }
// }

exports.Employee = class {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(value) {
        this._name = value;
    }
}