class DBLogger {
    log(message) {
        console.log(`${message}, logged in Database`);
    }
}

module.exports = DBLogger;