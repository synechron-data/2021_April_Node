console.log("Logged from logger->mylogger.js file");
